﻿using System;

namespace SalarityCalc1
{
	internal class Program
	{
		private ulong brutto, netto;
		private ulong przychod, dochod;
		private ulong zusEmertytalna;
		private ulong zusRentowaa;
		//private ulong zusWypadkowa;
		private ulong zusChorobowa;
		//private ulong zusFPiFS;
		private ulong zusSuma;
		private ulong nfzZdrowotna;
		private ulong pitZaliczka;
		Decimal d;

		public Program(ulong val)
		{
			brutto = val*100;
			przychod = brutto;
		}

		private ulong getBrutto()
		{
			return brutto;
		}

		static void Main(string[] args) {
			Program calc = new Program(10000);	//	pracownik
			//Program calc = new Program(4161);	//	przedsiębiorca
			calc.policz();
			calc.wypisz();
		}

		private ulong oblicz(ulong val, double procent)
		{
			/*double t1 = procent * value / 100;
			double t2 = Math.Round(t1);
			uint t3 = (uint)t2;

			Console.WriteLine("double: " + t1);
			Console.WriteLine("round : " + t2);
			Console.WriteLine("uint  : " + t3);
			Console.WriteLine("norm  : " + t3/100.0);

			return t3;*/
			return (ulong)Math.Round(val * procent / 100, MidpointRounding.AwayFromZero);	//	wynik '/100' bo mnożę przez procenty (%)
		}

		private ulong policzZUS()
		{
			//	Minimalna podstawa, od której liczy się składki w 2023 roku, wynosi 4161 zł
			zusEmertytalna	= oblicz(brutto, 9.76);		//	19,52%	9,76%
			zusRentowaa		= oblicz(brutto, 1.50);		//	 8,00%	1,50%
			zusChorobowa	= oblicz(brutto, 2.45);		//	 2,45%	2,45%; całą płaci pracownik
			//zusWypadkowa	= oblicz(brutto, 1.67);		//	 zmienna: od 0,67% do 3,33%; 1.67%, ale płaci pracodawca
			//zusFPiFS		= oblicz(brutto, 2.45);		//	 2,4%%, ale płaci pracodawca

			//return zusSuma = zusEmertytalna + zusRentowaa + zusWypadkowa + zusChorobowa + zusFPiFS;
			return zusSuma = zusEmertytalna + zusRentowaa + zusChorobowa;
		}

		private ulong policzNFZ()
		{
			return nfzZdrowotna = oblicz(dochod, 9);	//	9,00%	9,00%
		}

		private ulong policzPIT()
		{
			ulong kwotaWolna = 30000 * 100;	//	od 2022r.; '*100' bo wartość w groszach
			ulong kwotaZmniejszającaPodatek = oblicz(kwotaWolna, 12) / 12;  //	12.00%; /12 miesięcy = 300zł
			//Console.WriteLine(kwotaZmniejszającaPodatek);
			ulong koszty = 250 * 100;	//	albo 300; generalnie jest do tego gdzieś jakaś tabela 2x2

			//	testowanie funkcji Round():
			/*	for (dochod = 0; dochod < 12; dochod++)
					Console.WriteLine(dochod + " " + Math.Round(dochod*.1, MidpointRounding.AwayFromZero));	//	domyślnie źle zaokrągla 0.5; drugi argument działa na część ułamkową	*/

			//dochod = 2500 * 100 + 50;
			//ulong podstawaOpodatkowania = dochod - nfzZdrowotna;	//	ni kuta! nie zgadza się zaliczka!
			ulong podstawaOpodatkowania = (ulong)Math.Round((dochod-koszty) / 100.0, MidpointRounding.AwayFromZero) * 100;
			//Console.WriteLine(podstawaOpodatkowania);

			//Console.WriteLine(oblicz(podstawaOpodatkowania, 12));
			pitZaliczka = oblicz(podstawaOpodatkowania, 12);    //	12%
			if (pitZaliczka > kwotaZmniejszającaPodatek)
			{
				pitZaliczka -= kwotaZmniejszającaPodatek;
				return pitZaliczka = (ulong)Math.Round(pitZaliczka / 100.0, MidpointRounding.AwayFromZero) * 100;
			}
			return pitZaliczka = 0;

		}

		private void policz()
		{
			dochod = przychod - policzZUS();
			netto  = dochod   - policzNFZ() - policzPIT();
		}

		private void wypisz()
		{
			Console.WriteLine("Brutto     : " + brutto			/ 100.0);
			Console.WriteLine("Składki ZUS: ");
			Console.WriteLine("-emerytalna: " + zusEmertytalna	/ 100.0);
			Console.WriteLine("-rentowa   : " + zusRentowaa		/ 100.0);
			//Console.WriteLine("-wypadkowy : " + zusWypadkowa	/ 100.0);
			Console.WriteLine("-chorobowy : " + zusChorobowa / 100.0);
			//Console.WriteLine("-FP i FS   : " + zusFPiFS		/ 100.0);
			Console.WriteLine("= razem ZUS: " + zusSuma			/ 100.0);
			Console.WriteLine("Dochód     : " + dochod			/ 100.0);
			Console.WriteLine("Zdrowotna  : " + nfzZdrowotna	/ 100.0);
			Console.WriteLine("ZaliczkaPIT: " + pitZaliczka		/ 100.0);
			Console.WriteLine("Netto      : " + netto			/ 100.0);
		}
	}
}

//	.
//	https://zus.pox.pl/
//	