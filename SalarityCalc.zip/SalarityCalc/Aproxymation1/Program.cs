﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aproxymation1
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int a = 5000, b, i = 0,
				v = 673454, m;		//	v - value, m - medium

			a *= 100;
			b = 2 * a;
			Console.WriteLine(i++ + ": " + a + " " + b);

			do {
				m = (a + b) / 2;
				if (v > m)	a = m;
				else		b = m;
				Console.WriteLine(i++ + ": " + a + " " + b);

			} while (v != m);

			Console.WriteLine(m);
		}
	}
}

//	niby to działa, ale:
//	wartość poszukiwana musi mieścić się w przedziale otwartym (a, b), nigdy zamkniętym
//	czas poszukiwania wartości to czas logarytmiczny przy podstawie 2
