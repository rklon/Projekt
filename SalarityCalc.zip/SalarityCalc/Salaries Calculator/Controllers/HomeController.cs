﻿using Microsoft.AspNetCore.Mvc;
using Salaries_Calculator.Models;
using System.Diagnostics;

namespace Salaries_Calculator.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;

		public HomeController(ILogger<HomeController> logger)
		{
			_logger = logger;
		}

		public IActionResult Index(double value, string direction, string type, string pwz, string junior, string senior)
		{
			ViewData["Method"] = Request.Method;
			ViewBag.Value = value;
			ViewBag.Dir = direction;
			ViewBag.Type = type;

			ViewBag.pwz = pwz;
			ViewBag.junior = junior;
			ViewBag.senior = senior;

			Umowa umowa = null;

			if (Request.Method == "POST") {
				switch (type) {
					case "uopr": umowa = new UmowaOPracę(value); break;
					case "uodz": umowa = new UmowaODzieło(value); break;
					case "uzle": umowa = new UmowaZlecenie(value); break;
				}

				if (pwz	   == "on")	umowa.SetPWZ();
				if (junior == "on")	umowa.SetTAXfree();
				if (senior == "on")	umowa.SetTAXfree();

				if (direction == "brutto") umowa.ObliczNetto();
				else 					   umowa.ObliczBrutto();

				ViewBag.emerytalna	= String.Format("{0:0.00}", umowa.zusEmertytalna / 100.0);
				ViewBag.rentowa		= String.Format("{0:0.00}", umowa.zusRentowa / 100.0);
				ViewBag.chorobowa	= String.Format("{0:0.00}", umowa.zusChorobowa / 100.0);
				ViewBag.zusSuma		= String.Format("{0:0.00}", umowa.zusSuma / 100.0);

				ViewBag.dochód		= String.Format("{0:0.00}", umowa.dochod / 100.0);
				ViewBag.zdrowotna	= String.Format("{0:0.00}", umowa.nfzZdrowotna / 100.0);

				ViewBag.pitZaliczka = String.Format("{0:0.00}", umowa.pitZaliczka / 100.0);
				ViewBag.brutto		= String.Format("{0:0.00}", umowa.brutto / 100.0);
				ViewBag.netto		= String.Format("{0:0.00}", umowa.netto / 100.0);
			}

			return View(umowa);
		}

		public IActionResult Privacy()
		{
			return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}