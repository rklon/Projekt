﻿namespace Salaries_Calculator.Models
{
	abstract class Umowa
	{
		public ulong brutto, netto;
		public ulong przychod, dochod;
		public ulong zusEmertytalna, zusRentowa, zusChorobowa;
		//public ulong zusWypadkowa, zusFPiFS;
		public ulong zusSuma;
		public ulong nfzZdrowotna;
		public ulong pitZaliczka;

		protected bool PWZ, taxFree;

		public Umowa(double val)
		{
			brutto = (ulong)(val * 100);
			przychod = brutto;
		}

		public void RoundTest()
		{
			//	testowanie funkcji Round():
			for (dochod = 0; dochod < 12; dochod++)
				Console.WriteLine(dochod + " " + Math.Round(dochod * .1, MidpointRounding.AwayFromZero));
			//	domyślnie źle zaokrągla 0.5; drugi argument działa na część ułamkową
		}

		protected ulong obliczProcent(ulong val, double procent)
		{
			/*double t1 = procent * value / 100;
			double t2 = Math.Round(t1);
			uint t3 = (uint)t2;

			Console.WriteLine("double: " + t1);
			Console.WriteLine("round : " + t2);
			Console.WriteLine("uint  : " + t3);
			Console.WriteLine("norm  : " + t3/100.0);

			return t3;*/
			return (ulong)Math.Round(val * procent / 100, MidpointRounding.AwayFromZero);   //	wynik '/100' bo mnożę przez procenty (%)
		}

		protected abstract ulong policzZUS();

		protected virtual ulong policzNFZ()
		{
			return nfzZdrowotna = obliczProcent(dochod, 9);        //	9,00%	9,00%
		}

		protected abstract ulong policzPIT();

		public void ObliczNetto()
		{
			dochod = przychod - policzZUS();
			netto = dochod - policzNFZ() - policzPIT();
		}

		//	mam netto, a szukam brutto:
		public void ObliczBrutto()
		{
			ulong a, b, i = 0,
				  v, m;		//	v - value, m - medium

			v = brutto;		//	zapamiętanie obliczanej wartości netto
			a = v;			//	określenie zakresu poszukiwań
			b = 2 * a;
			//Console.WriteLine(i++ + ": " + a + " " + b);

			do
			{
				m = (a + b) / 2;
				brutto = przychod = m;
				ObliczNetto();
				if (v > netto) a = m;
				else b = m;
				//Console.WriteLine(i++ + ": " + a + " " + b);
			} while (v != netto);

			//Console.WriteLine(m);
			//Console.WriteLine(v);
		}

		public void wypisz()
		{
			Console.WriteLine("Brutto     : " + brutto / 100.0);
			Console.WriteLine("Składki ZUS: ");
			Console.WriteLine("-emerytalna: " + zusEmertytalna / 100.0);
			Console.WriteLine("-rentowa   : " + zusRentowa / 100.0);
			//Console.WriteLine("-wypadkowy : " + zusWypadkowa	/ 100.0);
			Console.WriteLine("-chorobowy : " + zusChorobowa / 100.0);
			//Console.WriteLine("-FP i FS   : " + zusFPiFS		/ 100.0);
			Console.WriteLine("= razem ZUS: " + zusSuma / 100.0);
			Console.WriteLine("Dochód     : " + dochod / 100.0);
			Console.WriteLine("Zdrowotna  : " + nfzZdrowotna / 100.0);
			Console.WriteLine("ZaliczkaPIT: " + pitZaliczka / 100.0);
			Console.WriteLine("Netto      : " + netto / 100.0);
		}

		internal void SetPWZ()
		{
			PWZ = true;
		}

		internal void SetTAXfree()
		{
			taxFree = true;
		}
	}

	class UmowaOPracę : Umowa
	{
		public UmowaOPracę(double val) : base(val) { }

		protected override ulong policzZUS()
		{
			//	Minimalna podstawa, od której liczy się składki w 2023 roku, wynosi 4161 zł
			zusEmertytalna = obliczProcent(przychod, 9.76);        //	19,52%	9,76%
			zusRentowa     = obliczProcent(przychod, 1.50);        //	 8,00%	1,50%
			zusChorobowa   = obliczProcent(przychod, 2.45);        //	 2,45%	2,45%; całą płaci pracownik
			//zusWypadkowa	= obliczProcent(przychod, 1.67);		//	 zmienna: od 0,67% do 3,33%; 1.67%, ale płaci pracodawca
			//zusFPiFS		= obliczProcent(przychod, 2.45);		//	 2,45%, ale płaci pracodawca

			//return zusSuma = zusEmertytalna + zusRentowa + zusWypadkowa + zusChorobowa + zusFPiFS;
			return zusSuma = zusEmertytalna + zusRentowa + zusChorobowa;
		}

		protected override ulong policzPIT()
		{
			if (taxFree) return pitZaliczka = 0;

			ulong kwotaWolna = 30000 * 100;     //	od 2022r.; '*100' bo wartość w groszach
			ulong kwotaZmniejszającaPodatek = obliczProcent(kwotaWolna, 12) / 12;  //	12.00%; /12 miesięcy = 300zł
			//Console.WriteLine(kwotaZmniejszającaPodatek);

			ulong koszty;
			if (PWZ) koszty = 250 * 100;    //	albo 300; generalnie jest do tego gdzieś jakaś tabela 2x2
			else	 koszty = 300 * 100;

			//dochod = 2500 * 100 + 50;
			//ulong podstawaOpodatkowania = dochod - nfzZdrowotna;	//	ni kuta! nie zgadza się zaliczka!
			ulong podstawaOpodatkowania = 0;
			if (dochod > koszty)
				podstawaOpodatkowania = (ulong)Math.Round((dochod - koszty) / 100.0, MidpointRounding.AwayFromZero) * 100;
			//Console.WriteLine(podstawaOpodatkowania);

			//Console.WriteLine(obliczProcent(podstawaOpodatkowania, 12));
			pitZaliczka = obliczProcent(podstawaOpodatkowania, 12);        //	12%
			if (pitZaliczka > kwotaZmniejszającaPodatek)
			{
				pitZaliczka -= kwotaZmniejszającaPodatek;
				return pitZaliczka = (ulong)Math.Round(pitZaliczka / 100.0, MidpointRounding.AwayFromZero) * 100;
			}
			return pitZaliczka = 0;
		}
	}

	class UmowaZlecenie : Umowa
	{
		public UmowaZlecenie(double val) : base(val) { }

		protected override ulong policzZUS()
		{
			zusEmertytalna = obliczProcent(przychod, 9.76);
			zusRentowa = obliczProcent(przychod, 1.50);

			return zusSuma = zusEmertytalna + zusRentowa;
		}

		protected override ulong policzPIT()
		{
			if (taxFree) return pitZaliczka = 0;

			ulong kwotaWolna = 30000 * 100;     //	od 2022r.; '*100' bo wartość w groszach
			ulong kwotaZmniejszającaPodatek = obliczProcent(kwotaWolna, 12) / 12;  //	12.00%; /12 miesięcy = 300zł

			ulong koszty = obliczProcent(dochod, 20);  //	albo 20% albo 50% dochodu

			ulong podstawaOpodatkowania = 0;
			if (dochod > koszty)
				podstawaOpodatkowania = (ulong)Math.Round((dochod - koszty) / 100.0, MidpointRounding.AwayFromZero) * 100;
			//Console.WriteLine(podstawaOpodatkowania);

			//Console.WriteLine(obliczProcent(podstawaOpodatkowania, 12));
			pitZaliczka = obliczProcent(podstawaOpodatkowania, 12);        //	12%
			if (pitZaliczka > kwotaZmniejszającaPodatek)
			{
				pitZaliczka -= kwotaZmniejszającaPodatek;
				return pitZaliczka = (ulong)Math.Round(pitZaliczka / 100.0, MidpointRounding.AwayFromZero) * 100;
			}
			return pitZaliczka = 0;
		}
	}

	class UmowaODzieło : Umowa
	{
		public UmowaODzieło(double val) : base(val) { }

		protected override ulong policzZUS()
		{
			return 0;
		}

		protected override ulong policzNFZ()
		{
			return 0;
		}

		protected override ulong policzPIT()
		{
			if (taxFree) return pitZaliczka = 0;

			//	Czyżby nie była uwzględniana kwota wolna od opodatkowania??

			ulong koszty = obliczProcent(dochod, 20);  //	albo 20% albo 50% dochodu

			ulong podstawaOpodatkowania = 0;
			if (dochod > koszty)
				podstawaOpodatkowania = (ulong)Math.Round((dochod - koszty) / 100.0, MidpointRounding.AwayFromZero) * 100;

			pitZaliczka = obliczProcent(podstawaOpodatkowania, 12);    //	12%

			return pitZaliczka = (ulong)Math.Round(pitZaliczka / 100.0, MidpointRounding.AwayFromZero) * 100;
		}
	}
}
